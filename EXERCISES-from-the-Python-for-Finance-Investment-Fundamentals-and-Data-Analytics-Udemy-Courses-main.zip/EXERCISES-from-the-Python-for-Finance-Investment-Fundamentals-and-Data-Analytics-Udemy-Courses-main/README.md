# EXERCISES-from-the-Python-for-Finance-Investment-Fundamentals-and-Data-Analytics-Udemy-Courses

This repository contains all of the personal notes and exercises and projects offered and completed from the Python for Finance Investment Fundamentals & Data Analytics on Udemy with the language Python:

- A Python Crash course 
- Python for Finance which includes Stock Market Data, Pandas Basics, Stock Data Analysis with Pandas, Visualizing Data with Matplotlib, Quantitative Trading Strategies, Trading with Moving Averages, Bollinger Bands, MACD and RSI
- Investment Fundamentals such as Asset Classes and Allocations, Calculate Risk and Return of portfolios, Investment Vehicles, Capital Asset Pricing Model
- Data Analytics and Visualization with Matplotlib , Data Analysis with Python, Data Visualization with Python, Portfolio Analysis, Markowitz Portfolio Optimization, Monte Carlo Simulations as a decision making tool, Creating stock charts from scratch
Univariate and Multivariate regression analysis with Technical Analysis.

Thank you !
